﻿namespace MvcApplication1.Models
{
    public class CartIndexVm
    {
        public Cart Cart { get; set; }
        public string ReturnUrl { get; set; }
    }
}